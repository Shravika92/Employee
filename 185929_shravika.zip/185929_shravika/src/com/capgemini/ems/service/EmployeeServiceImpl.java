package com.capgemini.ems.service;

import java.util.List;
import java.util.Scanner;

import com.capgemini.ems.dao.EmployeeDao;
import com.capgemini.ems.dao.EmployeeDaoImpl;
import com.capgemini.ems.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao dao = new EmployeeDaoImpl();
	private Scanner sc = new Scanner(System.in);
	
	@Override
	public void saveEmployee() {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		System.out.println("Enter Employee ID");
		e.setId(sc.nextInt());
		System.out.println("Enter Employee Name");
		e.setEmpname(sc.next());
		System.out.println("Enter Employee Salary");
		e.setSalary(sc.nextDouble());
		dao.save(e);
	}

	@Override
	public List<Employee> getEmployee() {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return dao.getEmpById(id);
	}

	@Override
	public Employee removeEmployeeById(int idd) {
		// TODO Auto-generated method stub
		return dao.removeEmployee(idd);
		
	}

	@Override
	public List<Employee> sortByName() {
		// TODO Auto-generated method stub
		return dao.sortName();
		
	}
	
	
}
