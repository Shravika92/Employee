package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.model.Employee;

public interface EmployeeService {
	
	void saveEmployee();
	
	List<Employee> getEmployee();
	
	Employee getEmployeeById(int id);

	Employee removeEmployeeById(int idd);

	List<Employee> sortByName();
}
