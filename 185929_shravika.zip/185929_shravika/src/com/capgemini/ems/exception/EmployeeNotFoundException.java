package com.capgemini.ems.exception;

public class EmployeeNotFoundException {

}
