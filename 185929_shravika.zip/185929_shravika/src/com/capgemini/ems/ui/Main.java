package com.capgemini.ems.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.ems.model.Employee;
import com.capgemini.ems.service.EmployeeService;
import com.capgemini.ems.service.EmployeeServiceImpl;

public class Main {
	private static EmployeeService service = new EmployeeServiceImpl();
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		String ch ="Yes";
		while(ch.contentEquals("Yes"))
		{
			System.out.println("Please enter your choice\n1. Enter Employee Details\n2. Get all Employee\n3. Get Employee Name by Id\n4. Delete Employee\n5. Sort by Name");
			int choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			service.saveEmployee();
			break;
		case 2:
			List<Employee> l = new ArrayList<Employee>();
			l = service.getEmployee();
			Iterator itr = l.iterator();
			while(itr.hasNext()) {
			System.out.println(itr.next());
			}
			break;
		case 3:
			System.out.println("Enter Employee Id");
			int id = sc.nextInt();
			Employee e = service.getEmployeeById(id);
			System.out.println("Employee details of given Id is\n"+e);
			break;
		case 4:
			System.out.println("Enter the Id to be deleted:");
			int idd = sc.nextInt(); 
			service.removeEmployeeById(idd);
			break;
		case 5:
			List<Employee> li = new ArrayList<Employee>();
			li = service.sortByName();
			Iterator itr2 = li.iterator();
			while(itr2.hasNext()) {
			System.out.println(itr2.next());
			}
			break;
		default:
		}
		System.out.println("Do you want to continue: Yes or No");
		ch=sc.next();
		}
	}
}
