package com.capgemini.ems.model;

public class Employee {
	private int id;
	String empname;
	double salary;
	private static String company = "Capgemini";
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public static String getCompany() {
		return company;
	}

	public static void setCompany(String company) {
		Employee.company = company;
	}

	@Override
	public String toString(){
		return "Employee: ID = " + id + ", Name = " + empname + ", Salary = " + salary + ", Company = " + company +"";
	
	}
	
}
