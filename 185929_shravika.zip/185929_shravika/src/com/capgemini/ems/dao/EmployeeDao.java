package com.capgemini.ems.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.ems.model.Employee;

public interface EmployeeDao {
	
	void save(Employee e);

	List<Employee> getAllEmployee();

	Employee getEmpById(int id);

	Employee removeEmployee(int idd);

	List<Employee> sortName();

}
