package com.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ems.dbutil.Dbutil;
import com.capgemini.ems.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private Connection con;
	
	@Override
	public void save(Employee e) {
		// TODO Auto-generated method stub
		con = Dbutil.getConnection();
		try {
			//Statement st = con.createStatement();
			PreparedStatement ps = con.prepareStatement("insert into shravs values(?,?,?)");
			ps.setInt(1, e.getId());
			ps.setString(2, e.getEmpname());
			ps.setDouble(3, e.getSalary());
			int i = ps.executeUpdate();
			if(i>0)
				System.out.println("Employee inserted Successfully!!!!");
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		
	}	
	
	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		
		con = Dbutil.getConnection();
		
		PreparedStatement ps;
		ResultSet rs;
		List<Employee> emp = null;;
		try {
			//Statement st = con.createStatement();
			ps = con.prepareStatement("select * from shravs");
			rs = ps.executeQuery();
			emp = new ArrayList<Employee>();
			while(rs.next())
			{
				Employee e = new Employee();
				try {
				e.setId(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setSalary(rs.getDouble(3));
				emp.add(e);
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		catch(SQLException e1)
		{
			System.out.println("Table is empty");
			e1.printStackTrace();
		}		
		return emp;
	}

	@Override
	public Employee getEmpById(int id) {
		// TODO Auto-generated method stub
		con = Dbutil.getConnection();
		Employee e = new Employee();
		PreparedStatement ps; 
		try {
		    ps = con.prepareStatement("select * from shravs where id = ?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				e.setId(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setSalary(rs.getDouble(3));
			}
		}
		catch(SQLException e1)
		{
			System.out.println("Employee of that ID is not Found");
			e1.printStackTrace();
		}
		return e;
	}

	@Override
	public Employee removeEmployee(int idd) {
		// TODO Auto-generated method stub
		con = Dbutil.getConnection();
		Employee e = new Employee();
		try {
			PreparedStatement ps = con.prepareStatement("delete from shravs where id = ?");
			ps.setInt(1, idd);
			int i = ps.executeUpdate();
			if(i>0)
				System.out.println("Employee Id deleted!!!");
		}
		catch(SQLException e1)
		{
			e1.printStackTrace();
		}
		return e;
	}

	@Override
	public List<Employee> sortName() {
		// TODO Auto-generated method stub
		con = Dbutil.getConnection();
		PreparedStatement ps = null;
		Employee e;// = new Employee();
		List<Employee> li = new ArrayList<Employee>();
		try {
			ps = con.prepareStatement("select * from shravs order by Name");
			ps.executeUpdate();
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				try {
				e= new Employee();
				e.setId(rs.getInt(1));
				e.setEmpname(rs.getString(2));
				e.setSalary(rs.getDouble(3));
				li.add(e);
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
				System.out.println("Table sorted!!!");
		}
		catch(SQLException e1)
		{
			System.out.println("Not Sorted");
			e1.printStackTrace();
		}
		
		return li;
	}
}
